# HBS Portal v2 Integrated Release

Upload/replace the full project contents, especially:
- index.html
- functions/api/audits.js
- functions/api/training.js
- functions/api/reaudits.js
- functions/api/login.js

What this release fixes:
- Restores Manager Dashboard data loading.
- Removes duplicate navigation buttons.
- Rebuilds role-based navigation.
- Keeps Mark Fuller as Senior Engineer.
- Senior Engineer can conduct audits but cannot access management dashboards/training/admin.
- Managers can see all audits, training records and re-audits.
- Engineers only see their own records where applicable.

Recommended:
1. Backup the current live portal first.
2. Upload this full project to the same GitHub branch.
3. Wait for Cloudflare Pages deployment to complete.
4. Hard refresh the browser: Ctrl + F5.
